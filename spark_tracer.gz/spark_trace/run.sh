
if [ -z "${SPARK_HOME}" ]; then
  echo 'NO SPARK_HOME, please set SPARK_HOME'
  echo 'eg. export SPARK_HOME=/usr/local/spark'
  exit 1
fi
echo ${SPARK_HOME}
rm -rf metastore_db
export SPARK_LOG_LEVEL=ERROR
export scp=`find ${SPARK_HOME}/jars -name '*.jar' | xargs | sed  "s/ /:/g"`
export libs=`find ./jars | xargs | sed  "s/ /,/g"`
echo ${libs}
spark-submit --master local --num-executors 2 --executor-cores 2 --executor-memory 2G --driver-memory 2G --jars ${libs} --class com.sqllineage.SparkShell spark_sql-1.0.0.jar 2>r.log
